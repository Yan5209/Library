#!/bin/sh
# CNSWatchdog.sh — 看守狗启动脚本
# 自动检测 JB_ROOT 并启动 daemon watchdog 模式

# 检测 JB_ROOT (扫描 .jbroot-*)
JBROOT_BASE="/var/mobile/Containers/Shared/AppGroup"
for dir in "$JBROOT_BASE"/.jbroot-*; do
    if [ -d "$dir" ]; then
        export JB_ROOT="$dir"
        break
    fi
done

if [ -z "$JB_ROOT" ]; then
    echo "CNSWatchdog: 无法检测 JB_ROOT, 退出"
    exit 0  # 干净退出, 不触发 launchd 错误计数
fi

# V27.8: 使用 JB_ROOT 前缀路径, 确保 roothide 下 daemon 能被找到
DAEMON="${JB_ROOT}/usr/libexec/CNSVibrationCacheDaemon"
if [ ! -x "$DAEMON" ]; then
    echo "CNSWatchdog: daemon 不存在于 $DAEMON, 退出"
    exit 0
fi

exec "$DAEMON" --watchdog
