export THEOS=~/theos
#language
LANG=zh_CN.UTF-8
LANGUAGE=zh_CN.UTF-8
if [ "$(id -u)" -ne 0 ]; then
exec sudo -i
fi